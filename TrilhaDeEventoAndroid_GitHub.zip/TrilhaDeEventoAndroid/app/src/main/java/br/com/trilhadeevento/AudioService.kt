package br.com.trilhadeevento

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.content.pm.ServiceInfo
import android.media.AudioAttributes

class AudioService : Service() {
    companion object {
        const val SET_MAIN="set_main", START_MAIN="start_main", PLAY_CUE="play_cue", TOGGLE_CUE="toggle_cue",
            STOP_CUE="stop_cue", PAUSE_ALL="pause_all", EMERGENCY_STOP="emergency_stop",
            MAIN_VOL="main_vol", CUE_VOL="cue_vol", FADE="fade", DUCK="duck"
        const val EXTRA_DATA="data", CHANNEL="trilha_audio"
    }
    private var main:MediaPlayer?=null
    private var cue:MediaPlayer?=null
    private val handler=Handler(Looper.getMainLooper())
    private var mainVolume=0.65f
    private var cueVolume=1f
    private var duck=0.15f
    private var fadeMs=3000L
    private var cueActive=false
    private var mainUri:Uri?=null
    private var mainPrepared=false
    private var cuePrepared=false
    private var mainWanted=false

    override fun onBind(intent:Intent?)=null
    override fun onCreate() { super.onCreate(); createChannel() }

    override fun onStartCommand(intent:Intent?, flags:Int, startId:Int):Int {
        ensureForeground()
        val data=intent?.getStringExtra(EXTRA_DATA)
        when(intent?.action) {
            SET_MAIN -> { mainUri=data?.let(Uri::parse); prepareMain() }
            START_MAIN -> startMain()
            PLAY_CUE -> data?.let { playCue(Uri.parse(it)) }
            TOGGLE_CUE -> toggleCue()
            STOP_CUE -> stopCue()
            PAUSE_ALL -> { main?.pause(); cue?.pause(); cueActive=false; applyMainVolume() }
            EMERGENCY_STOP -> { main?.pause(); cue?.pause(); main?.seekTo(0); cue?.seekTo(0); cueActive=false; mainWanted=false; applyMainVolume() }
            MAIN_VOL -> { mainVolume=(data?.toFloatOrNull()?:65f)/100f; applyMainVolume() }
            CUE_VOL -> { cueVolume=(data?.toFloatOrNull()?:100f)/100f; cue?.setVolume(cueVolume,cueVolume) }
            FADE -> fadeMs=(data?.toLongOrNull()?:3L)*1000L
            DUCK -> { duck=(data?.toFloatOrNull()?:15f)/100f; applyMainVolume() }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            val nm=getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL,"Trilha de Evento",NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun ensureForeground() {
        val notification=Notification.Builder(this, if(Build.VERSION.SDK_INT>=26) CHANNEL else "")
            .setContentTitle("Trilha de Evento")
            .setContentText("Controle de áudio em execução")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build()
        if(Build.VERSION.SDK_INT>=29) startForeground(7,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(7,notification)
    }
    private fun prepareMain() {
        val uri=mainUri?:return
        try {
            main?.release()
            main=MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@AudioService,uri)
                isLooping=true
                setOnPreparedListener { mainPrepared=true; if(mainWanted) startMain() }
                prepareAsync()
            }
        } catch (_:Exception) {}
    }
    private fun startMain() {
        mainWanted=true
        if(main==null){prepareMain();return}
        if(mainPrepared) try { if(main?.isPlaying!=true)main?.start(); applyMainVolume() } catch (_:Exception) {}
    }
    private fun playCue(uri:Uri) {
        try {
            cue?.release(); cuePrepared=false
            cue=MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@AudioService,uri)
                setOnPreparedListener { cuePrepared=true; setVolume(cueVolume,cueVolume); cueActive=true; fadeCueIn(); if(mainWanted && main?.isPlaying!=true) startMain() }
                setOnCompletionListener { cueActive=false; fadeMainToNormal() }
                prepareAsync()
            }
            fadeMainToDuck()
        } catch (_:Exception) { cueActive=false; applyMainVolume() }
    }
    private fun toggleCue() {
        val p=cue?:return
        try {
            if(p.isPlaying){p.pause();cueActive=false;applyMainVolume()}
            else if(cuePrepared){p.start();cueActive=true;fadeMainToDuck()}
        } catch (_:Exception) {}
    }
    private fun stopCue() { try { cue?.pause();cue?.seekTo(0) } catch (_:Exception) {}; cueActive=false; fadeMainToNormal() }

    private fun applyMainVolume() {
        val target=if(cueActive) mainVolume*duck else mainVolume
        main?.setVolume(target,target)
    }
    private fun fadeMainToDuck() { cueActive=true; fadeMain(mainVolume*duck) }
    private fun fadeMainToNormal() { cueActive=false; fadeMain(mainVolume) }
    private fun fadeMain(target:Float) {
        val p=main?:return
        val steps=20; val from=mainVolume // volume ramp approximate; set current through captured effective start
        val start=if(cueActive) mainVolume else (p.currentPosition.let { if(cueActive) mainVolume*duck else mainVolume })
        val duration=fadeMs
        if(duration<=0){p.setVolume(target,target);return}
        val step=duration/steps
        for(i in 1..steps) handler.postDelayed({
            try { val v=start+(target-start)*i/steps; p.setVolume(v,v) } catch (_:Exception) {}
        },step*i)
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { main?.release(); cue?.release() } catch (_:Exception) {}
        super.onDestroy()
    }
}
