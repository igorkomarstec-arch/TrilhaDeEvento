package br.com.trilhadeevento

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.content.Context

class MainActivity : Activity() {
    private val tracks = mutableListOf<Pair<String, Uri>>()
    private var mainUri: Uri? = null
    private lateinit var mainLabel: TextView
    private lateinit var playlistBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var fadeSeek: SeekBar
    private lateinit var duckSeek: SeekBar
    private lateinit var mainVol: SeekBar
    private lateinit var cueVol: SeekBar
    private var selected = -1

    private val mainPicker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persist(it); mainUri = it
            mainLabel.text = displayName(it)
            command(AudioService.SET_MAIN, it.toString())
        }
    }
    private val listPicker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { persist(it); tracks.add(displayName(it) to it) }
        renderPlaylist()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildUi()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
        }
    }

    private fun persist(uri: Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
    }

    private fun displayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else uri.lastPathSegment ?: "Áudio"
            } ?: (uri.lastPathSegment ?: "Áudio")
        } catch (_: Exception) { uri.lastPathSegment ?: "Áudio" }
    }

    private fun buildUi() {
        val bg = Color.rgb(16,20,28); val panel = Color.rgb(28,35,48); val accent = Color.rgb(139,211,199)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,24,28,32); setBackgroundColor(bg) }
        scroll.addView(col); setContentView(scroll)
        fun title(t:String, size:Float=20f) = TextView(this).apply { text=t; textSize=size; setTextColor(Color.WHITE); setPadding(0,16,0,8) }
        fun button(t:String, action:()->Unit) = Button(this).apply { text=t; setOnClickListener { action() } }
        fun section() = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,12,18,16); setBackgroundColor(panel) }
        fun addSection(s:LinearLayout) { val p=LinearLayout.LayoutParams(-1,-2); p.bottomMargin=16; col.addView(s,p) }
        col.addView(title("Trilha de Evento",26f))
        col.addView(TextView(this).apply { text="Player de ambiente e músicas de entrada • offline"; setTextColor(0xFFABB5C5.toInt()); textSize=13f })
        val a=section(); a.addView(title("🎼 Música principal / ambiente"))
        mainLabel=TextView(this).apply { text="Nenhuma música selecionada"; setTextColor(Color.WHITE); textSize=14f; setPadding(0,8,0,8) }; a.addView(mainLabel)
        a.addView(button("Escolher música principal") { mainPicker.launch(arrayOf("audio/*")) })
        a.addView(title("Volume da principal"))
        mainVol=SeekBar(this).apply { max=100; progress=65; setOnSeekBarChangeListener(simpleListener { command(AudioService.MAIN_VOL, it.toString()) }) }; a.addView(mainVol)
        addSection(a)

        val b=section(); b.addView(title("🎧 Playlist de entradas"))
        b.addView(button("Adicionar músicas do celular") { listPicker.launch(arrayOf("audio/*")) })
        playlistBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,8,0,4) }; b.addView(playlistBox)
        b.addView(button("▶ Tocar aleatória") { playRandom() })
        b.addView(button("Ⅱ Pausar / retomar entrada") { command(AudioService.TOGGLE_CUE) })
        b.addView(button("■ Parar entrada") { command(AudioService.STOP_CUE) })
        b.addView(title("Volume das entradas"))
        cueVol=SeekBar(this).apply { max=100; progress=100; setOnSeekBarChangeListener(simpleListener { command(AudioService.CUE_VOL,it.toString()) }) }; b.addView(cueVol)
        addSection(b)

        val c=section(); c.addView(title("⚙️ Transições"))
        c.addView(title("Duração do fade: 3 segundos"))
        fadeSeek=SeekBar(this).apply { max=10; progress=3; setOnSeekBarChangeListener(simpleListener { command(AudioService.FADE,it.toString()) }) }; c.addView(fadeSeek)
        c.addView(title("Volume ambiente durante entrada: 15%"))
        duckSeek=SeekBar(this).apply { max=50; progress=15; setOnSeekBarChangeListener(simpleListener { command(AudioService.DUCK,it.toString()) }) }; c.addView(duckSeek)
        addSection(c)

        val d=section(); d.addView(title("▶ Controle geral"))
        d.addView(button("Iniciar ambiente") { mainUri?.let { command(AudioService.START_MAIN) } ?: toast("Escolha a música principal primeiro.") })
        d.addView(button("Pausar tudo") { command(AudioService.PAUSE_ALL) })
        d.addView(button("PARADA DE EMERGÊNCIA") { command(AudioService.EMERGENCY_STOP) })
        status=TextView(this).apply { text="Pronto. Selecione os arquivos de áudio."; setTextColor(accent); textSize=13f; setPadding(0,12,0,0) }; d.addView(status)
        addSection(d)
        col.addView(TextView(this).apply { text="Dica: conecte a caixa Bluetooth antes de iniciar. O áudio continua em segundo plano; teste no seu aparelho antes do evento."; setTextColor(0xFFABB5C5.toInt()); textSize=12f; setPadding(0,8,0,8) })
    }

    private fun simpleListener(onChange:(Int)->Unit)=object:SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar:SeekBar?, progress:Int, fromUser:Boolean) { if(fromUser) onChange(progress) }
        override fun onStartTrackingTouch(seekBar:SeekBar?) {}
        override fun onStopTrackingTouch(seekBar:SeekBar?) {}
    }

    private fun renderPlaylist() {
        playlistBox.removeAllViews()
        if (tracks.isEmpty()) { playlistBox.addView(TextView(this).apply { text="Nenhuma música adicionada."; setTextColor(0xFFABB5C5.toInt()) }); return }
        tracks.forEachIndexed { i, item ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val name=TextView(this).apply { text="${i+1}. ${item.first}"; setTextColor(Color.WHITE); textSize=13f; setPadding(0,8,6,8); layoutParams=LinearParams(0,-2,1f) }
            val play=Button(this).apply { text="▶"; setOnClickListener { selected=i; command(AudioService.PLAY_CUE,item.second.toString()); status.text="Tocando: ${item.first}" } }
            row.addView(name); row.addView(play); playlistBox.addView(row)
        }
    }

    private fun playRandom() {
        if(tracks.isEmpty()){ toast("Adicione músicas à playlist primeiro."); return }
        val idx=if(tracks.size==1) 0 else (tracks.indices.filter{it!=selected}.random())
        selected=idx; command(AudioService.PLAY_CUE,tracks[idx].second.toString()); status.text="Tocando: ${tracks[idx].first}"
    }

    private fun command(action:String, data:String?=null) {
        val i=Intent(this,AudioService::class.java).setAction(action)
        if(data!=null)i.putExtra(AudioService.EXTRA_DATA,data)
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
    }
    private fun toast(t:String)=Toast.makeText(this,t,Toast.LENGTH_SHORT).show()
    private fun LinearParams(w:Int,h:Int,weight:Float)=LinearLayout.LayoutParams(w,h,weight)
}
